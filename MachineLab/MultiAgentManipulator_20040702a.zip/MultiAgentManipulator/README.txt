run CHANGE_JOINTS.bat to switch between 14 and 140 pins (unconstrained spherical joints in this version of the simulator)

during simulation use arrow keys and PgUp/PgDn to guide the manipulator head (robot tooltip) in the 3D space

have fun,
George Birbilis

(C)2004 G.Birbilis (birbilis@kagi.com)
http://www.mech.upatras.gr/~robgroup/agents/multi-agent/
